from django import forms
from .models import Staff
class Staff_form(forms.ModelForm):
    class Meta:
        model=Staff
        fields="__all__"
class searchform(forms.ModelForm):
    class Meta:
        model=Staff
        fields=['sname','sdept']
class updateform(forms.Form):
    sid=forms.IntegerField()
    sname=forms.CharField(max_length=20)
    sage=forms.IntegerField()
