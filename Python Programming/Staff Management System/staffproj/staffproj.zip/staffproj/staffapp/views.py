from django.shortcuts import render
from django.http import HttpResponse,HttpResponseRedirect
from .models import Staff
from .forms import Staff_form
from .forms import searchform
from .forms import updateform
# Create your views here.
def search(request):
    form=searchform()
    if request.method=="POST":
            form=searchform(request.POST)
            if form.is_valid():
                n=form.cleaned_data['sname']
                d=form.cleaned_data['sdept']
                a=Staff.objects.get(sname=n,sdept=d)
                return render(request,'display.html',context={'t':a})
            #    except:
              #      return HttpResponse('<h1>Staff not found</h1>')
    return render(request,'update.html',context={'staff':form})
def insert_view(request):
    form=Staff_form()
    if request.method=="POST":
        form=Staff_form(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponse('<center><h1>Inserted Successfully</h1></center>')
    return render(request,'insert.html',context={'form':form})
def update_view(request):
    form=updateform()
    if request.method=="POST":
            form=searchform(request.POST)
            if form.is_valid():
                i=form.cleaned_data['sid']
                n=form.cleaned_data['sname']
                age=form.cleaned_data['sage']
                a=Staff.objects.get(sid=i)
                a.sname=n
                a.sage=age
             #   a.sdept=sdept
                return HttpResponse('<h1>Updated Sucessfully</h1>')
                #except:
                  #  return HttpResponse('<h1>Staff not found</h1>')
    return render(request,'update.html',context={'staff':form})
def delete_view(request,t):
    a=Staff.objects.get(sid=t)
    a.delete()
    return HttpResponse('<center><h1>Deleted Successfully</h1></center>')
